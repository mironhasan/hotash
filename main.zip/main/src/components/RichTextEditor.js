import React from "react";
import JoditEditor from "jodit-react";

export default function RichTextEditor() {

	return (
		<JoditEditor />
	)
}