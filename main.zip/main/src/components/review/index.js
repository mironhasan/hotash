export { default as CustomerReview } from "./CustomerReview";
export { default as RatingAnalytics } from "./RatingAnalytics";